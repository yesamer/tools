/*
 * Copyright (c) OSGi Alliance (2012, 2019). All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Namespace Package Version 1.2.
 * 
 * <p>
 * Bundles should not need to import this package at runtime since all
 * the types in this package just contain constants for capability and 
 * requirement namespaces specified by the OSGi Alliance.
 * 
 * @author $Id: 43f3804d39ad166dc082926b3a3679be67962fcc $
 */

@Version("1.2")
package org.osgi.framework.namespace;

import org.osgi.annotation.versioning.Version;

